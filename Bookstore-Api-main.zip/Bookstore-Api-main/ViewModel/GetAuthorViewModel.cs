﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Store.ViewModel
{
    public class GetAuthorViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
